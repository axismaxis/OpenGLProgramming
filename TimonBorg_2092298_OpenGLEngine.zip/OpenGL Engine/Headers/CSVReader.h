#pragma once

class CSVReader
{
public:
	CSVReader();
	~CSVReader();
private:

};